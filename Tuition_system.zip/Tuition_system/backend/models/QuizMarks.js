import mongoose from "mongoose";

const QuizMarkSchema = new mongoose.Schema({
  studentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Student1",
    required: true
  },
  quizDate: {
    type: String,   // "YYYY-MM-DD"
    required: true
  },
  score: {
    type: Number,
    required: true
  },
  maxScore: {
    type: Number,
    required: true
  }
}, { timestamps: true });

export default mongoose.model("QuizMark", QuizMarkSchema);
