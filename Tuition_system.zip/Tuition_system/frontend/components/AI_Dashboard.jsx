import { useEffect, useState } from "react";
import axios from "axios";

export default function AIDashboard() {
  const [weak, setWeak] = useState([]);
  const [defaulters, setDefaulters] = useState([]);
  const [trends, setTrends] = useState([]);
  const [progress, setProgress] = useState([]);

  useEffect(() => {
    axios.get("/api/dashboard/weak-students").then(r => setWeak(r.data));
    axios.get("/api/dashboard/payment-defaulters").then(r => setDefaulters(r.data));
    axios.get("/api/dashboard/attendance-trends").then(r => setTrends(r.data));
    axios.get("/api/dashboard/class-progress").then(r => setProgress(r.data));
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>📊 AI Powered Tuition Dashboard</h2>

      {/* Weak Students */}
      <h3>🔴 Weak Students</h3>
      <ul>
        {weak.map((s, i) => (
          <li key={i}>{s.name} — {s.attendanceRate}</li>
        ))}
      </ul>

      {/* Defaulters */}
      <h3>⚠️ Payment Defaulters</h3>
      <ul>
        {defaulters.map((s, i) => (
          <li key={i}>{s.name} — {s.lastPayment}</li>
        ))}
      </ul>

      {/* Trends */}
      <h3>📈 Attendance Trends (Last Days)</h3>
      <ul>
        {trends.map((t, i) => (
          <li key={i}>{t.date}: {t.attendanceRate}%</li>
        ))}
      </ul>

      {/* Class Progress */}
      <h3>🏫 Class Progress</h3>
      <ul>
        {progress.map((c, i) => (
          <li key={i}>{c.className}: {c.avgAttendance}%</li>
        ))}
      </ul>
    </div>
  );
}
