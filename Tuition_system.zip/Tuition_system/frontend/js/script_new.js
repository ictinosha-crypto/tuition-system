document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('studentRegisterForm1'); // 
  const messageBox = document.getElementById('formMessage2');  // 

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); // Prevent page reload

      const studentData = {
        fullName: document.getElementById('fullName').value,
        dob: document.getElementById('dob').value,
        gender: document.getElementById('gender').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        grade: document.getElementById('grade').value,
        address: document.getElementById('address').value
      };

      try {
        const response = await fetch('/register-student-new1', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(studentData)
        });

        const result = await response.json();

        if (response.ok) {
          messageBox.innerHTML = `
            <div class="alert alert-success">
              <strong>${result.message}</strong><br>
              Student No: <b>${result.studentNumber}</b>
            </div>`;
          form.reset();
        } else {
          messageBox.innerHTML = `<div class="alert alert-danger">${result.message || 'Registration failed.'}</div>`;
        }
      } catch (error) {
        console.error(error);
        messageBox.innerHTML = `<div class="alert alert-danger">Error submitting the form.</div>`;
      }
    });



//******************************************** */



  }
});
