import mongoose from "mongoose";

const NoteSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  topic: String,
  filename: { type: String, required: true }, // stored filename on disk
  fileUrl: { type: String, required: true },  // public URL path like /notes/xxx.pdf
  uploadedAt: { type: Date, default: () => new Date() }
});

export default mongoose.model("Note", NoteSchema);
