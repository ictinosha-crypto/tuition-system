// src/components/Dashboard.jsx
import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import Chart from "chart.js/auto";
import "bootstrap/dist/css/bootstrap.min.css";
import "../css/style1.css";

export default function Dashboard() {
  const [currentDateTime, setCurrentDateTime] = useState("");
  const [totalStudents, setTotalStudents] = useState(0);
  const [presentCount, setPresentCount] = useState(0);
  const [absentCount, setAbsentCount] = useState(0);
  const [totalCollected, setTotalCollected] = useState(0);
  const [gradeData, setGradeData] = useState({}); // { "6": { total, present, absent }, ... }
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const attendanceCanvasRef = useRef(null);
  const gradeCanvasRef = useRef(null);
  const attendanceChartRef = useRef(null);
  const gradeChartRef = useRef(null);

  // live date/time
  useEffect(() => {
    function update() {
      const now = new Date();
      const dateStr = now.toLocaleDateString(undefined, {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      });
      const timeStr = now.toLocaleTimeString();
      setCurrentDateTime(`${dateStr} | ${timeStr}`);
    }
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);

  // Normalize various potential response shapes for gradewise data
  function normalizeGradeData(raw) {
    if (!raw) return {};
    const out = {};

    // If API returns an array
    if (Array.isArray(raw)) {
      raw.forEach((item) => {
        const g = item.grade ?? item._id ?? item.name ?? "Unknown";
        const total =
          item.total ??
          item.totalStudents ??
          item.count ??
          item.totalCount ??
          0;
        const present =
          item.present ?? item.presentCount ?? item.presentStudents ?? 0;
        const absent =
          item.absent ?? item.absentCount ?? item.absentStudents ??
          Math.max(0, total - present);
        out[g] = { total, present, absent };
      });
      return out;
    }

    // If API returns an object keyed by grade
    if (typeof raw === "object") {
      Object.entries(raw).forEach(([g, stats]) => {
        if (!stats) {
          out[g] = { total: 0, present: 0, absent: 0 };
          return;
        }
        const total =
          stats.total ??
          stats.totalStudents ??
          stats.count ??
          stats.totalCount ??
          0;
        const present =
          stats.present ?? stats.presentCount ?? stats.presentStudents ?? 0;
        const absent =
          stats.absent ??
          stats.absentCount ??
          stats.absentStudents ??
          Math.max(0, total - present);
        out[g] = { total, present, absent };
      });
      return out;
    }

    return {};
  }

  // Fetch all data
  useEffect(() => {
    let mounted = true;
    async function loadAll() {
      setLoading(true);
      setError(null);
      try {
        // 1) Summary
        const res = await axios.get("/api/attendance-summary_new");
        const s = res?.data ?? {};
        if (!mounted) return;
        setTotalStudents(s.totalStudents ?? s.total ?? 0);
        setPresentCount(s.presentCount ?? s.present ?? 0);
        const ac =
          s.absentCount ??
          s.absent ??
          ( (s.totalStudents ?? s.total ?? 0) - (s.presentCount ?? s.present ?? 0) );
        setAbsentCount(ac >= 0 ? ac : 0);

        // 2) Grade wise summary
        const res2 = await axios.get("/api/attendance-summary-gradewise3");
        const gradRaw = res2?.data ?? {};
        if (!mounted) return;
        const norm = normalizeGradeData(gradRaw);
        setGradeData(norm);

        // 3) Today's payments total
        try {
          const p = await axios.get("/api/payments/today/total");
          const pData = p?.data ?? {};
          setTotalCollected(pData.totalAmount ?? pData.total ?? 0);
        } catch (err) {
          // ignore payment error but log
          console.warn("Payment fetch failed:", err);
          setTotalCollected(0);
        }

        // optional: fetch gradewise present list endpoint (if you want)
        // await axios.get('/api/attendance/today/gradewise2').then(r => console.log(r.data)).catch(()=>{});

        setLoading(false);
      } catch (err) {
        console.error(err);
        if (!mounted) return;
        setError("Failed to load dashboard data");
        setLoading(false);
      }
    }

    loadAll();
    // refresh data every 60 seconds while mounted (optional)
    const interval = setInterval(loadAll, 60000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  // (re)draw attendance doughnut when presentCount/absentCount changes
  useEffect(() => {
    const ctxNode = attendanceCanvasRef.current;
    if (!ctxNode) return;

    const data = {
      labels: ["Present", "Absent"],
      datasets: [{
        data: [presentCount || 0, absentCount || 0],
        backgroundColor: ["#24B773", "#F24454"],
      }]
    };

    if (attendanceChartRef.current) {
      // update existing chart
      attendanceChartRef.current.data = data;
      attendanceChartRef.current.update();
    } else {
      attendanceChartRef.current = new Chart(ctxNode, {
        type: "doughnut",
        data,
        options: { responsive: true, maintainAspectRatio: false }
      });
    }

    return () => {
      // do not destroy here (we want reuse); destruction on unmount
    };
  }, [presentCount, absentCount]);

  // (re)draw grade-wise bar chart when gradeData changes
  useEffect(() => {
    const node = gradeCanvasRef.current;
    if (!node) return;
    const labels = Object.keys(gradeData);
    const totalData = labels.map(g => gradeData[g]?.total ?? 0);
    const presentData = labels.map(g => gradeData[g]?.present ?? 0);
    const absentData = labels.map(g => gradeData[g]?.absent ?? 0);

    const datasets = [
      { label: "Total Students", data: totalData, backgroundColor: "rgba(79,176,224,0.7)" },
      { label: "Present Today", data: presentData, backgroundColor: "rgba(36,183,115,0.7)" },
      { label: "Absent Today", data: absentData, backgroundColor: "rgba(242,68,84,0.7)" },
    ];

    if (gradeChartRef.current) {
      gradeChartRef.current.data.labels = labels;
      gradeChartRef.current.data.datasets = datasets;
      gradeChartRef.current.update();
    } else {
      gradeChartRef.current = new Chart(node, {
        type: "bar",
        data: { labels, datasets },
        options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } } }
      });
    }
    // cleanup on unmount handled below
  }, [gradeData]);

  // destroy charts on unmount
  useEffect(() => {
    return () => {
      try {
        if (attendanceChartRef.current) {
          attendanceChartRef.current.destroy();
          attendanceChartRef.current = null;
        }
        if (gradeChartRef.current) {
          gradeChartRef.current.destroy();
          gradeChartRef.current = null;
        }
      } catch (e) {
        // ignore
      }
    };
  }, []);

  // Render
  return (
    <div>
      <div className="navbar-custom">
        <div className="user-role"><i className="fa-solid fa-user-shield" /> Admin</div>
        <div className="date-time" id="currentDateTime">{currentDateTime}</div>
      </div>

      <div className="main-content">
        <h2 className="mb-4">Welcome to the Admin Dashboard</h2>

        {error && <div className="alert alert-danger">{error}</div>}
        {loading && <div className="mb-3">Loading dashboard...</div>}

        <div className="row g-4">
          <div className="col-md-3">
            <div className="card text-white shadow-sm total_std">
              <div className="card-body">
                <h5 className="card-title">Total Students</h5>
                <p className="card-text fs-3" id="totalStudents">{totalStudents}</p>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card text-white shadow-sm bg-success present">
              <div className="card-body">
                <h5 className="card-title">Today's Attendance</h5>
                <p className="card-text fs-3" id="presentStudents">{presentCount}</p>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card text-white shadow-sm bg-danger">
              <div className="card-body">
                <h5 className="card-title">Pending Payments</h5>
                <p className="card-text fs-3" id="absentStudents">{absentCount}</p>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card text-white shadow-sm bg-danger money">
              <div className="card-body">
                <h5 className="card-title">Total Collected</h5>
                <p className="card-text fs-3" id="totalCollected">{totalCollected}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4" id="gradeAttendanceContainer">
          {Object.keys(gradeData).length === 0 ? (
            <div>Loading attendance summary...</div>
          ) : (
            <div className="table-responsive">
              <table className="table table-bordered table-striped">
                <thead><tr><th>Grade</th><th>Total Students</th><th>Present</th><th>Absent</th></tr></thead>
                <tbody>
                  {Object.entries(gradeData).map(([grade, stats]) => (
                    <tr key={grade}>
                      <td>{grade}</td>
                      <td>{stats.total}</td>
                      <td>{stats.present}</td>
                      <td>{stats.absent}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="row mt-4">
          <div className="col-md-6">
            <h4>Today's Attendance Chart</h4>
            <div style={{height: 250}}>
              <canvas ref={attendanceCanvasRef} id="attendanceChart" />
            </div>
          </div>

          <div className="col-md-6">
            <h4>Grade-wise Attendance</h4>
            <div style={{height: 300}}>
              <canvas ref={gradeCanvasRef} id="gradeAttendanceChart" />
            </div>
          </div>
        </div>

        <footer className="mt-4">
          &copy; 2025 TECHNEST. All rights reserved.
        </footer>
      </div>
    </div>
  );
}
