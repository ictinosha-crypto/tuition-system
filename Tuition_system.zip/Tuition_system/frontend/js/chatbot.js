function toggleChatbot() {
    const box = document.getElementById("chatbot-box");
    box.style.display = box.style.display === "none" ? "block" : "none";
}

function sendChatbot() {
    const input = document.getElementById("chatbot-input").value.trim();
    const student = JSON.parse(localStorage.getItem("student"));
    
    if (!input) return;

    addMessage("You", input, "user-msg");

    document.getElementById("chatbot-input").value = "";

    fetch("/api/chatbot/ask", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            studentId: student.studentId,
            message: input
        })
    })
    .then(res => res.json())
    .then(data => {
        addMessage("Bot", data.reply, "bot-msg");
    });
}

function addMessage(sender, text, cssClass) {
    const msgBox = document.getElementById("chatbot-messages");
    msgBox.innerHTML += `<div class="msg ${cssClass}">${text}</div>`;
    msgBox.scrollTop = msgBox.scrollHeight;
}
