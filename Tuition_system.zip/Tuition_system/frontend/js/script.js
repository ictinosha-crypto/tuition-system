document.addEventListener('DOMContentLoaded', () => {
  //console.log('Student list page script running');
  //console.log("✅ DOM fully loaded");


  // 🔵 Highlight Active Sidebar Link
  const currentPath = window.location.pathname.split('/').pop();
  const sidebarLinks = document.querySelectorAll('.sidebar a');

  sidebarLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // 🔵 Dynamic Page Title
  const pageTitleMap = {
    'dashboard.html': 'Dashboard',
    'register.html': 'Register Student',
    'student-list.html': 'Student List',
    'attendance.html': 'Attendance',
    'export.html': 'Export',
    'logout.html': 'Logout',
  };

  //start insert user
  document.getElementById('page-title').innerText = pageTitleMap[currentPath] || 'Tuition System';

  // 🔵 Handle Student Form Submission (if form exists)
  const form = document.getElementById('registerForm');
  if (form) {
    form.addEventListener('submit', async function (e) {
      e.preventDefault();

      const name = document.getElementById('name').value;
      const pass = document.getElementById('pass').value;
      const formMessage = document.getElementById('formMessage');

      try {
        const response = await fetch('/register-user', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ name, pass })
        });

        const text = await response.text();

        if (response.ok) {
          formMessage.innerHTML = `
            <div class="alert alert-success">
              <i class="fa-solid fa-circle-check me-2"></i> ${text}
            </div>`;
          form.reset();
        } else {
          formMessage.innerHTML = `<div class="alert alert-danger">${text}</div>`;
        }
      } catch (error) {
        formMessage.innerHTML = `<div class="alert alert-danger">Something went wrong. Please try again.</div>`;
      }
    });
    //end insert user

//***************************** */












// student-register second form

  const form = document.getElementById('studentForm');
  const message = document.getElementById('formMessage');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const data = {
      fullName: document.getElementById('fullName').value,
      dob: document.getElementById('dob').value,
      gender: document.getElementById('gender').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      grade: document.getElementById('grade').value,
      address: document.getElementById('address').value
    };

    try {
      const res = await fetch('/register-student-new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await res.json();

      if (res.ok) {
        message.innerHTML = `
          <div class="alert alert-success">
            ${result.message} <br>
            <strong>Student No:</strong> ${result.studentNumber}
          </div>`;
        form.reset();
      } else {
        message.innerHTML = `<div class="alert alert-danger">${result.message}</div>`;
      }
    } catch (err) {
      console.error(err);
      message.innerHTML = `<div class="alert alert-danger">Error submitting form</div>`;
    }
  });




//*************************** */









    // Clear messages on input
    const formMessage = document.getElementById('formMessage');
    const inputs = form.querySelectorAll('input, select, textarea');

    inputs.forEach(input => {
      input.addEventListener('input', () => {
        if (formMessage) {
          formMessage.innerHTML = '';  // Clear the message
        }
      });
    });
  }

  // 🔵 Load student list if on student-list page
  if (currentPath === 'student-list1.html') {
    (async () => {
      try {
        const response = await fetch('/api/users');
        if (!response.ok) throw new Error('Failed to fetch users');
        const users = await response.json();

        const tbody = document.querySelector('table tbody');
        tbody.innerHTML = ''; // Clear existing rows if any

        users.forEach((user, index) => {
          const tr = document.createElement('tr');

          tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${user.name}</td>
            <td>${user.pass}</td>  <!-- Grade (no field yet) -->
            <td>
              <button class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></button>
              <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
            </td>
          `;

          tbody.appendChild(tr);
        });
      } catch (err) {
        console.error(err);
        alert('Error loading student list.');
      }
    })();
  }



//
// Add the fetch user count here
  fetch('/api/students/count')
    .then(response => {
      if (!response.ok) throw new Error('Failed to fetch user count');
      return response.json();
    })
    .then(data => {
      const totalStudentsElem = document.querySelector('.card.bg-primary .card-text');
      if (totalStudentsElem) {
        totalStudentsElem.textContent = data.count;
      }
    })
    .catch(error => {
      console.error('Error fetching user count:', error);
    });


// student register

  // 🔵 Handle Student Registration Form
const studentForm = document.getElementById('registerstd');
const studentMessage = document.getElementById('formMessage');

if (studentForm) {
  studentForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = {
      fullName: document.getElementById('fullName').value,
      dob: document.getElementById('dob').value,
      gender: document.getElementById('gender').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      grade: document.getElementById('grade').value,
      address: document.getElementById('address').value,
    };

    try {
      const response = await fetch('/register-student', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      const text = await response.text();

      if (response.ok) {
        studentMessage.innerHTML = `
          <div class="alert alert-success">
            <i class="fa-solid fa-circle-check me-2"></i> ${text}
          </div>`;
        studentForm.reset();
      } else {
        studentMessage.innerHTML = `
          <div class="alert alert-danger">
            <i class="fa-solid fa-circle-xmark me-2"></i> ${text}
          </div>`;
      }
    } catch (error) {
      studentMessage.innerHTML = `
        <div class="alert alert-danger">
          <i class="fa-solid fa-triangle-exclamation me-2"></i> Error submitting form
        </div>`;
      console.error(error);
    }
  });

  // Clear message on input
  studentForm.querySelectorAll('input, select, textarea').forEach(input => {
    input.addEventListener('input', () => {
      studentMessage.innerHTML = '';
    });
  });
}

// end register students

//start view all students
 // 🔵 Load student list if on student-list page
  if (currentPath === 'student-list.html') {
    (async () => {
      try {
        const response = await fetch('/api/students');
        if (!response.ok) throw new Error('Failed to fetch students');
        const users = await response.json();

        const tbody = document.querySelector('table tbody');
        tbody.innerHTML = ''; // Clear existing rows if any

        users.forEach((std, index) => {
          const tr = document.createElement('tr');

          tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${std.fullName}</td>
            <td>${std.dob}</td>  
            <td>${std.gender}</td>
            <td>${std.phone}</td>  
            <td>${std.grade}</td>
            <td>${std.address}</td>  

            <td>
              <button class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></button>
              <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
            </td>
          `;

          tbody.appendChild(tr);
        });
      } catch (err) {
        console.error(err);
        alert('Error loading student list.');
      }
    })();
  }






  //end view all students


//loaidstudents according to grade in attendance mark
// Grade select change



//end load std in attendence






  //attendance mark

  const gradeSelect = document.getElementById('grade');
  const attendanceTableBody = document.querySelector('table tbody');
  const attendanceForm = document.querySelector('form');
  const formMessage = document.createElement('div');
 // attendanceForm.insertBefore(formMessage, attendanceForm.querySelector('button[type="submit"]'));
//const attendanceForm = document.querySelector('form');
//const formMessage = document.createElement('div');

if (attendanceForm) {
  const submitBtn = attendanceForm.querySelector('button[type="submit"]');
  if (submitBtn) {
    attendanceForm.insertBefore(formMessage, submitBtn);
  } else {
    console.warn('Submit button not found in attendance form');
  }
} else {
  console.warn('Attendance form not found on this page');
}




  // Load students when grade changes
  gradeSelect.addEventListener('change', async () => {
    const grade = gradeSelect.value;
    if (!grade) {
      attendanceTableBody.innerHTML = '';
      return;
    }

    try {
      const res = await fetch(`/api/students/by-grade?grade=${encodeURIComponent(grade)}`);
      if (!res.ok) throw new Error('Failed to fetch students');
      const students = await res.json();

      if (students.length === 0) {
        attendanceTableBody.innerHTML = `<tr><td colspan="2">No students found for ${grade}</td></tr>`;
        return;
      }

      // Build rows dynamically
      attendanceTableBody.innerHTML = '';
      students.forEach(student => {
        const tr = document.createElement('tr');

        tr.innerHTML = `
          <td>${student.fullName}</td>
          <td>
            <select name="attendance[${student._id}]" class="form-select" required>
              <option value="">-- Select --</option>
              <option value="present">Present</option>
              <option value="absent">Absent</option>
            </select>
          </td>
        `;

        attendanceTableBody.appendChild(tr);
      });
    } catch (error) {
      attendanceTableBody.innerHTML = `<tr><td colspan="2">Error loading students</td></tr>`;
      console.error(error);
    }
  });

  // Handle form submit with fetch (AJAX)
  attendanceForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Gather form data
    const formData = new FormData(attendanceForm);
    const classDate = formData.get('classDate');
    const grade = formData.get('grade');

    if (!classDate || !grade) {
      formMessage.innerHTML = `<div class="alert alert-danger">Please select class date and grade.</div>`;
      return;
    }

    // Build attendance data object
    const attendanceData = { date: classDate, grade, records: [] };

    // attendance[studentId] => present/absent
    for (let [key, value] of formData.entries()) {
      if (key.startsWith('attendance[')) {
        const studentId = key.slice(11, -1); // extract studentId from attendance[studentId]
        attendanceData.records.push({ studentId, status: value });
      }
    }

    if (attendanceData.records.length === 0) {
      formMessage.innerHTML = `<div class="alert alert-danger">No attendance records to submit.</div>`;
      return;
    }

    try {
      const res = await fetch('/submit-attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(attendanceData)
      });

      const text = await res.text();

      if (res.ok) {
        formMessage.innerHTML = `<div class="alert alert-success">${text}</div>`;
        attendanceForm.reset();
        attendanceTableBody.innerHTML = ''; // clear table
      } else {
        formMessage.innerHTML = `<div class="alert alert-danger">${text}</div>`;
      }
    } catch (err) {
      formMessage.innerHTML = `<div class="alert alert-danger">Error submitting attendance.</div>`;
      console.error(err);
    }
  });


  //end attendance mark


  const reportForm = document.getElementById('reportForm');
  const reportMessage = document.getElementById('reportMessage');
  const reportTable = document.getElementById('attendanceReportTable');
  const tbody = reportTable.querySelector('tbody');

  if (reportForm && reportMessage && reportTable && tbody) {
  reportForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const date = document.getElementById('reportDate').value;
    const grade = document.getElementById('reportGrade').value;

    if (!date || !grade) {
      reportMessage.innerHTML = `<div class="alert alert-danger">Please select date and grade.</div>`;
      return;
    }

    reportMessage.innerHTML = '';
    tbody.innerHTML = '';
    reportTable.style.display = 'none';

    try {
      const response = await fetch(`/api/attendance-report?date=${encodeURIComponent(date)}&grade=${encodeURIComponent(grade)}`);
      if (!response.ok) throw new Error('Failed to fetch report');

      const data = await response.json();

      if (data.records.length === 0) {
        reportMessage.innerHTML = `<div class="alert alert-info">No attendance records found for ${grade} on ${date}.</div>`;
        return;
      }

      data.records.forEach((record, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${idx + 1}</td>
          <td>${record.studentName}</td>
          <td>${record.status.charAt(0).toUpperCase() + record.status.slice(1)}</td>
        `;
        tbody.appendChild(tr);
      });

      reportTable.style.display = '';
    } catch (error) {
      console.error(error);
      reportMessage.innerHTML = `<div class="alert alert-danger">Error loading report. Please try again.</div>`;
    }
  });
}


  //end attendence mark
const form1 = document.getElementById('studentRegisterForm1');
const messageBox = document.getElementById('formMessage2');
 console.log("Form1:", form1); // check if it's null
 
if (form1) {
  form1.addEventListener('submit', async (e) => {
    e.preventDefault(); // ✅ Stop page refresh
    alert('Submit caught!');

    const studentData = {
      fullName: document.getElementById('fullName').value,
      dob: document.getElementById('dob').value,
      gender: document.getElementById('gender').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      grade: document.getElementById('grade').value,
      address: document.getElementById('address').value
    };

    try {
      const response = await fetch('/register-student-new1', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(studentData)
      });

      const result = await response.json();

      if (response.ok) {
        messageBox.innerHTML = `
          <div class="alert alert-success">
            <i class="fa-solid fa-circle-check me-2"></i>
            ${result.message}<br>
            <strong>Student Number:</strong> ${result.studentNumber || ''}
          </div>`;
        form1.reset();
      } else {
        messageBox.innerHTML = `
          <div class="alert alert-danger">
            <i class="fa-solid fa-circle-xmark me-2"></i>
            ${result.message || 'Registration failed'}
          </div>`;
      }
    } catch (error) {
      console.error('Fetch error:', error);
      messageBox.innerHTML = `
        <div class="alert alert-danger">
          <i class="fa-solid fa-triangle-exclamation me-2"></i>
          Failed to submit form. Please try again.
        </div>`;
    }
  });

  form1.querySelectorAll('input, select, textarea').forEach(input => {
    input.addEventListener('input', () => {
      messageBox.innerHTML = '';
    });
  });
}



//end std reg second form


  






  //******************************************** */
});
