document.addEventListener("DOMContentLoaded", async () => {
  try {
    // Find the header and footer containers
    const header = document.getElementById("header");
    const footer = document.getElementById("footer");

    // Load header only if container exists
    if (header) {
      const res = await fetch("header.html");
      if (res.ok) {
        header.innerHTML = await res.text();
      } else {
        console.warn("⚠️ header.html not found");
      }
    }

    // Load footer only if container exists
    if (footer) {
      const res = await fetch("footer.html");
      if (res.ok) {
        footer.innerHTML = await res.text();
      } else {
        console.warn(" footer.html not found");
      }
    }
  } catch (err) {
    console.error("include.js error:", err);
  }


document.getElementById("menu-toggle").addEventListener("click", function(){
    document.querySelector(".sidebar").classList.toggle("active");
});






});
