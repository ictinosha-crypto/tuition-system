import mongoose from "mongoose";

const activityLogSchema = new mongoose.Schema({
  userName: { type: String, required: true },
  action: { type: String, required: true },       // e.g., "Added Student", "Marked Attendance"
  details: { type: String },                      // optional extra info
  timestamp: { type: Date, default: Date.now }
});

export default mongoose.model("ActivityLog", activityLogSchema);
