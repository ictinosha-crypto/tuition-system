// Reorganized and cleaned script.js

document.addEventListener('DOMContentLoaded', () => {
  highlightSidebar();
  updatePageTitle();
  initUserRegistration();
  initStudentRegistration();
  initStudentFormNew();
  initStudentList();
  fetchStudentCount();
  initAttendance();
  initAttendanceReport();
});

function highlightSidebar() {
  const currentPath = window.location.pathname.split('/').pop();
  document.querySelectorAll('.sidebar a').forEach(link => {
    const href = link.getAttribute('href');
    link.classList.toggle('active', href === currentPath);
  });
}

function updatePageTitle() {
  const pageTitleMap = {
    'dashboard.html': 'Dashboard',
    'register.html': 'Register Student',
    'student-list.html': 'Student List',
    'attendance.html': 'Attendance',
    'export.html': 'Export',
    'logout.html': 'Logout',
  };
  const currentPath = window.location.pathname.split('/').pop();
  const pageTitle = document.getElementById('page-title');
  if (pageTitle) pageTitle.innerText = pageTitleMap[currentPath] || 'Tuition System';
}

function initUserRegistration() {
  const form = document.getElementById('registerForm');
  if (!form) return;
  const formMessage = document.getElementById('formMessage');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const pass = document.getElementById('pass').value;

    try {
      const response = await fetch('/register-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, pass })
      });

      const text = await response.text();

      formMessage.innerHTML = response.ok
        ? `<div class="alert alert-success">${text}</div>`
        : `<div class="alert alert-danger">${text}</div>`;
      if (response.ok) form.reset();
    } catch {
      formMessage.innerHTML = `<div class="alert alert-danger">Something went wrong. Please try again.</div>`;
    }
  });

  form.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', () => {
      formMessage.innerHTML = '';
    });
  });
}

function initStudentRegistration() {
  const form = document.getElementById('studentForm');
  if (!form) return;
  const message = document.getElementById('formMessage');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());

    try {
      const res = await fetch('/register-student-new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const result = await res.json();

      message.innerHTML = res.ok
        ? `<div class="alert alert-success">${result.message}<br><strong>Student No:</strong> ${result.studentNumber}</div>`
        : `<div class="alert alert-danger">${result.message}</div>`;
      if (res.ok) form.reset();
    } catch {
      message.innerHTML = `<div class="alert alert-danger">Error submitting form</div>`;
    }
  });

  form.querySelectorAll('input, select, textarea').forEach(input => {
    input.addEventListener('input', () => {
      message.innerHTML = '';
    });
  });
}

function initStudentFormNew() {
  const form1 = document.getElementById('studentRegisterForm1');
  if (!form1) return;
  const messageBox = document.getElementById('formMessage2');

  form1.addEventListener('submit', async (e) => {
    e.preventDefault();
    const studentData = Object.fromEntries(new FormData(form1).entries());

    try {
      const response = await fetch('/register-student-new1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studentData)
      });

      const result = await response.json();
      messageBox.innerHTML = response.ok
        ? `<div class="alert alert-success">${result.message}<br><strong>Student Number:</strong> ${result.studentNumber || ''}</div>`
        : `<div class="alert alert-danger">${result.message || 'Registration failed'}</div>`;
      if (response.ok) form1.reset();
    } catch {
      messageBox.innerHTML = `<div class="alert alert-danger">Failed to submit form. Please try again.</div>`;
    }
  });

  form1.querySelectorAll('input, select, textarea').forEach(input => {
    input.addEventListener('input', () => {
      messageBox.innerHTML = '';
    });
  });
}

function initStudentList() {
  const currentPath = window.location.pathname.split('/').pop();
  if (currentPath !== 'student-list.html') return;

  fetch('/api/students')
    .then(res => res.json())
    .then(users => {
      const tbody = document.querySelector('table tbody');
      if (!tbody) return;
      tbody.innerHTML = '';
      users.forEach((user, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${idx + 1}</td>
          <td>${user.fullName}</td>
          <td>${user.dob}</td>
          <td>${user.gender}</td>
          <td>${user.phone}</td>
          <td>${user.grade}</td>
          <td>${user.address}</td>
          <td>
            <button class="btn btn-sm btn-warning">Edit</button>
            <button class="btn btn-sm btn-danger">Delete</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    })
    .catch(err => alert('Error loading student list.'));
}

function fetchStudentCount() {
  const elem = document.querySelector('.card.bg-primary .card-text');
  if (!elem) return;

  fetch('/api/students/count')
    .then(res => res.json())
    .then(data => {
      elem.textContent = data.count;
    })
    .catch(console.error);
}

function initAttendance() {
  const form = document.querySelector('form');
  const gradeSelect = document.getElementById('grade');
  const tableBody = document.querySelector('table tbody');
  if (!form || !gradeSelect || !tableBody) return;

  const formMessage = document.createElement('div');
  const submitBtn = form.querySelector('button[type="submit"]');
  if (submitBtn) form.insertBefore(formMessage, submitBtn);

  gradeSelect.addEventListener('change', async () => {
    const grade = gradeSelect.value;
    if (!grade) return (tableBody.innerHTML = '');

    try {
      const res = await fetch(`/api/students/by-grade?grade=${encodeURIComponent(grade)}`);
      const students = await res.json();

      tableBody.innerHTML = students.length === 0
        ? `<tr><td colspan="2">No students found for ${grade}</td></tr>`
        : students.map(student => `
          <tr>
            <td>${student.fullName}</td>
            <td>
              <select name="attendance[${student._id}]" class="form-select" required>
                <option value="">-- Select --</option>
                <option value="present">Present</option>
                <option value="absent">Absent</option>
              </select>
            </td>
          </tr>`).join('');
    } catch {
      tableBody.innerHTML = `<tr><td colspan="2">Error loading students</td></tr>`;
    }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    const attendanceData = {
      date: formData.get('classDate'),
      grade: formData.get('grade'),
      records: []
    };

    formData.forEach((value, key) => {
      if (key.startsWith('attendance[')) {
        const studentId = key.slice(11, -1);
        attendanceData.records.push({ studentId, status: value });
      }
    });

    if (!attendanceData.date || !attendanceData.grade || attendanceData.records.length === 0) {
      formMessage.innerHTML = `<div class="alert alert-danger">Fill required fields.</div>`;
      return;
    }

    try {
      const res = await fetch('/submit-attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(attendanceData)
      });
      const text = await res.text();
      formMessage.innerHTML = res.ok
        ? `<div class="alert alert-success">${text}</div>`
        : `<div class="alert alert-danger">${text}</div>`;
      if (res.ok) {
        form.reset();
        tableBody.innerHTML = '';
      }
    } catch {
      formMessage.innerHTML = `<div class="alert alert-danger">Error submitting attendance.</div>`;
    }
  });
}

function initAttendanceReport() {
  const reportForm = document.getElementById('reportForm');
  const reportMessage = document.getElementById('reportMessage');
  const reportTable = document.getElementById('attendanceReportTable');
  if (!reportForm || !reportMessage || !reportTable) return;

  const tbody = reportTable.querySelector('tbody');

  reportForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const date = document.getElementById('reportDate').value;
    const grade = document.getElementById('reportGrade').value;

    if (!date || !grade) {
      reportMessage.innerHTML = `<div class="alert alert-danger">Please select date and grade.</div>`;
      return;
    }

    reportMessage.innerHTML = '';
    tbody.innerHTML = '';
    reportTable.style.display = 'none';

    try {
      const response = await fetch(`/api/attendance-report?date=${date}&grade=${grade}`);
      const data = await response.json();

      if (!data.records.length) {
        reportMessage.innerHTML = `<div class="alert alert-info">No attendance found.</div>`;
        return;
      }

      tbody.innerHTML = data.records.map((record, i) => `
        <tr>
          <td>${i + 1}</td>
          <td>${record.studentName}</td>
          <td>${record.status.charAt(0).toUpperCase() + record.status.slice(1)}</td>
        </tr>`).join('');

      reportTable.style.display = '';
    } catch {
      reportMessage.innerHTML = `<div class="alert alert-danger">Error loading report.</div>`;
    }
  });
}
