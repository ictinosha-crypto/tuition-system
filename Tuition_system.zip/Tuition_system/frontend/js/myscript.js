 document.addEventListener('DOMContentLoaded', async () => {
  const gradeSelect = document.getElementById('grade');

  try {
    const response = await fetch('/api/classes');
    const classList = await response.json();

    // Clear existing options
    gradeSelect.innerHTML = '<option value="">-- Select Class --</option>';

    classList.forEach(cls => {
      const option = document.createElement('option');
      option.value = cls._id; // Save ID if you plan to use it
      option.textContent = `${cls.className}`;
      gradeSelect.appendChild(option);
    });
  } catch (err) {
    console.error('Error loading class list:', err);
  }



function updateDateTime() {
  const now = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const dateStr = now.toLocaleDateString(undefined, options);
  const timeStr = now.toLocaleTimeString();
  document.getElementById('currentDateTime').innerText = `${dateStr} | ${timeStr}`;
}
setInterval(updateDateTime, 1000);
updateDateTime();

//document.getElementById('updateForm').style.display = 'none';



});